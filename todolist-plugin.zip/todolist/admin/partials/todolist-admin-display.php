<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       aleksanderciesla.pl
 * @since      1.0.0
 *
 * @package    Todolist
 * @subpackage Todolist/admin/partials
 */
?>

<div class="mybody">

    <div class="mylist">
        <!-- <div class="row ">
            <div class="row__status">
                <input type="checkbox">
            </div>
            <div class="row__content" title="Click to edit">
                <input type="text" placeholder="Enter new task here...">
            </div>
            <div class="row__act">
                <span class="dashicons dashicons-upload row_hidden" title="Save"></span>
                <span class="dashicons dashicons-dismiss row_hidden" title="Cancel"></span>
            </div>
        </div>
         <div class="row ">
            <div class="row__status">
                <input type="checkbox">
            </div>
            <div class="row__content" title="Click to edit">
                <input type="text" value="Play soccer with friends">
            </div>
            <div class="row__act"> 
                <span class="dashicons dashicons-trash" title="Delete"></span> 
                <span class="dashicons dashicons-upload row_hidden" title="Save"></span> 
                <span class="dashicons dashicons-dismiss row_hidden" title="Cancel"></span> 
            </div>
        </div> -->
    </div>

</div>